## KiCad Particle Parts

KiCad Parts for Particle hardware (e.g. Core, Photon, Electron).

Feel free to contribute new parts!

## Included

- Photon Schematics Symbol
- Photon Footprint

## License

MIT License.
